<?php

	require 'vendor/autoload.php';
	$app = new \Slim\Slim();
	
	// Serveur RestFull
	// ...
?>