<?php
	$smarty->display("accueil.tpl");
?>
